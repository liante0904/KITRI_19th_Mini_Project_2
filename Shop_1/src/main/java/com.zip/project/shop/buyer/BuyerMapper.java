package com.project.shop.buyer;

import java.util.List;

public interface BuyerMapper {

	//īƮ
	void insertCart(Cart c);
		
	void deleteCart(int cart_num);
	
	List<Cart> selectCart(String id);
	
	
	
	// buy
	void insertBuy(Buy p);
	Cart selectCartByNum(int cart_num);
	List<Buy> selectBuy(String id); // īƮ ��ü����

	
	
	

}
