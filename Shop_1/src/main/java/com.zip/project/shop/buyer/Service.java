package com.project.shop.buyer;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Component;

import com.project.shop.seller.Product;

@Component("buyerService")
public class Service implements BuyerService {


	@Resource(name="sqlSession")
	private SqlSession SqlSession;
	
	
	
	void setSqlSession(SqlSession sqlSession) {
		SqlSession = sqlSession;
	}

	@Override
	public void AddCart(Cart c) {
		// TODO Auto-generated method stub
		BuyerMapper buyermapper = SqlSession.getMapper(BuyerMapper.class);
		buyermapper.insertCart(c);
	

	}

	@Override
	public void DelProduct(int cart_num) {
		// TODO Auto-generated method stub
		BuyerMapper buyermapper = SqlSession.getMapper(BuyerMapper.class);
		buyermapper.deleteCart(cart_num);
	}

	@Override
	public List<Buy> selectBuy(String id) {
		// TODO Auto-generated method stub
		BuyerMapper buyermapper = SqlSession.getMapper(BuyerMapper.class);
		return buyermapper.selectBuy(id);
	}

	@Override
	public List<Cart> selectCart(String id) {
		BuyerMapper buyermapper = SqlSession.getMapper(BuyerMapper.class);
		return buyermapper.selectCart(id);
	}

	@Override
	public void BuyProduct(Buy p) {
		BuyerMapper buyermapper = SqlSession.getMapper(BuyerMapper.class);
		buyermapper.insertBuy(p);		
	}

	@Override
	public Cart selectCartByNum(int cart_num) {
		BuyerMapper buyermapper = SqlSession.getMapper(BuyerMapper.class);
		return buyermapper.selectCartByNum(cart_num);
	}



}
