package com.project.shop.cont;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.shop.member.Member;
import com.project.shop.member.MemberService;
import com.project.shop.seller.Product;
import com.project.shop.seller.ProductService;

@Controller
public class MainController {
	@Resource(name="prodService")
	ProductService prod_service;

	public void setService(ProductService service) {
		this.prod_service = service;
	}

	@Resource(name="memService")
	MemberService mem_service;

	public void setService(MemberService service) {
		this.mem_service = service;
	}



	//����������
	@RequestMapping(value="/")
	public ModelAndView main(){
		ModelAndView mav = new ModelAndView("/main/main");
		mav.addObject("list", prod_service.selectProd());
		return mav;
	}

	//��ǰ������ �� VIEW
	@RequestMapping(value="/view.do")
	public ModelAndView prod_view(@RequestParam(value = "num") int num){
		ModelAndView mav = new ModelAndView("/product/prodView");
		Product pro = prod_service.select(num);
		mav.addObject("product", pro);

		return mav;
	}


	//�α��������� �̵�
	@RequestMapping(value="/loginForm.do")
	public ModelAndView loginForm(){

		ModelAndView mav = new ModelAndView("/member/loginForm");
		//mav.addObject("list", prod_service.selectProd());
		return mav;
	}
	//ȸ������������ �̵�
	@RequestMapping(value="/joinForm.do")
	public ModelAndView joinForm(){
		ModelAndView mav = new ModelAndView("/member/joinForm");
		//mav.addObject("list", prod_service.selectProd());
		return mav;
	}
	//ȸ������ ���������� �ߺ�üũ ��û
	@RequestMapping(value="/idCheck.do")
	public ModelAndView idCheck(@RequestParam(value="id") String id){
		ModelAndView mav = new ModelAndView("/member/check");
		Member m = mem_service.getMember(id);
		boolean flag;
		if (m==null) {
			flag = true;
		}else{
			flag = false;
		}
		mav.addObject("flag", flag);
		return mav;
	}


	//ȸ������ ��û(DB�ݿ�)
	@RequestMapping(value="/join_submit.do")
	public ModelAndView join_submit(Member m){
		ModelAndView mav = new ModelAndView("/main/main");
		mem_service.addMember(m);
		return mav;
	}
	//�α��� �õ�
	@RequestMapping(value="/login.do")
	public ModelAndView login(Member m,HttpServletRequest req){
		HttpSession session = null;

		ModelAndView mav = new ModelAndView("/main/main");
		boolean flag= mem_service.login(m);
		if (flag) {
			session = req.getSession();
			session.setAttribute("id", m.getId());
			}else if(flag){
			mav = new ModelAndView("/main/loginForm");
			}
		return mav;
	}

	@RequestMapping(value="/logout.do")
	public ModelAndView login(HttpSession session ){
		ModelAndView mav = new ModelAndView("/main/main");
		session.invalidate();
		return mav;
	}
	// ȸ������ ������ �̵�
	@RequestMapping(value="/editForm.do")
	public ModelAndView editForm(HttpSession session){
		ModelAndView mav = new ModelAndView("/member/editForm");
		Member m = mem_service.getMember(session.getAttribute("id").toString());
		mav.addObject("m",m);
		return mav;
	}
	@RequestMapping(value="/edit_submit.do")
	public ModelAndView edit_submit(HttpSession session,Member m){
		ModelAndView mav = new ModelAndView("/main/main");
		
		mem_service.editMember(m);
		
		return mav;
	}





}
