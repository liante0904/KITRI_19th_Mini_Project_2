package com.project.shop.cont;

import java.util.ArrayList;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.project.shop.seller.Product;
import com.project.shop.seller.ProductService;

@Controller
public class SellerController {
	@Resource(name="prodService")
	ProductService service;

	public void setService(ProductService service) {
		this.service = service;
	}
	
	
	//DB�� ��ǰ���
	@RequestMapping(value = "seller/add.do")
	public String add(Product p) {
		System.out.println(p);
/*		String file1Name = p.getFile1().getOriginalFilename();
		String file2Name = p.getFile2().getOriginalFilename();
		String path1 = "C:\\Users\\Administrator\\Desktop\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\webapps\\img\\"
				+ file1Name;
		
		String path2 = "C:\\Users\\Administrator\\Desktop\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\webapps\\img\\"
				+ file2Name;
		File f1 = new File(path1);
		File f2 = new File(path2);
		try {
			p.getFile1().transferTo(f1);
			p.getFile2().transferTo(f2);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		p.setPROD_IMAGE1("/img/" + file1Name);
		p.setPROD_IMAGE2("/img/" + file2Name);
		service.insertProd(p);*/
		return "seller/list";
	}

	
	@RequestMapping(value = "seller/addPage.do")
	public String gg(Product p) {				//�ۼ��ϷḦ ������ ����Ʈ�� ���°�
		return "seller/addForm";
	}
	
	//�ڱⰡ ����� ��ǰ�� ���
	@RequestMapping(value = "seller/list.do")
	public ModelAndView list(HttpServletRequest req) {
		HttpSession session = null;
		session = req.getSession();
		ArrayList<Product> p = (ArrayList<Product>) service.selectProdById((String)session.getAttribute("id")); //����!
		//���� ���̵�� ��ǰ��� LIST
		ModelAndView mav = new ModelAndView("seller/list");
		mav.addObject("p", p);
		return mav;
		
	}
	
}
